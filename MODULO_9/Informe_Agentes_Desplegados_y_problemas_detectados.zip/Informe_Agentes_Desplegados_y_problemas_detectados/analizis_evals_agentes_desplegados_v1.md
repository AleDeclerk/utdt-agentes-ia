# Agentes en producción: cómo se evalúan y cómo se rastrean cuando ya están actuando

### Lectura guiada del informe de la OCDE «Agentic AI in organisations» (2026), con foco en evaluación y trazabilidad

*Material de apoyo del curso de Arquitectura de Agentes IA (UTDT) · versión 1 · 21 de octubre de 2026*

> **Estado de esta versión.** El análisis se hizo únicamente sobre el informe de la OCDE (36 páginas) y su Anexo A. No se contrastó con fuentes externas, ni se leyeron los trabajos que el informe cita. Es una v1 pensada para discutir con alumnos y, después, verificar.

---

## En 60 segundos

- La OCDE entrevistó a 25 organizaciones (de 74 contactadas) que ya desarrollan o usan agentes de IA. Su conclusión es que los agentes están pasando de los experimentos a los flujos de trabajo reales, pero con **autonomía acotada** y con una **gobernanza todavía inmadura**.
- Entre las brechas que el informe destaca hay dos que son el tema de este texto: **evaluación** (las herramientas para evaluar sistemas agénticos están «significativamente menos maduras» que las que existen para un LLM aislado) y **trazabilidad** (reconstruir qué hizo un agente y por qué se vuelve muy difícil con muchos pasos, varios agentes o varias organizaciones).
- El cambio de fondo: antes evaluábamos **respuestas**; ahora hay que evaluar **trayectorias y efectos**. Una respuesta mala se corrige. Una acción mala (borrar datos, aprobar un pago) ya ocurrió.
- **El informe no publica fallas de productos concretos.** Describe desafíos anónimos y, aparte, en un anexo, qué agentes tienen las organizaciones. En este texto cruzamos ambas cosas y marcamos siempre cuál es cuál.
- Incluso las afirmaciones de trazabilidad de los proveedores («cada afirmación se puede rastrear a su fuente») son **autodeclaradas**: el estudio no incluye evaluaciones independientes. Evaluar la evaluación es parte del problema.

---

## Cómo leer este texto

Cada vez que tratamos un agente o un desafío, hablamos con dos voces distintas, y conviene no mezclarlas:

- **En el informe.** Lo que la OCDE dice, parafraseado y traducido por nosotros. Con la página cuando corresponde, tal como está *impresa* en el informe (el visor de PDF suma una por la portada). Cuando el texto procede del Anexo A, lo decimos: son descripciones que las propias organizaciones dieron de sus productos.
- **Nuestra lectura.** Interpretación, extrapolación o ejemplo didáctico nuestro. **No está en el informe** y puede estar equivocada. Es la parte que más conviene discutir y verificar.

Para poder cruzar los desafíos con los agentes del anexo, numeramos los desafíos que el informe describe:

- **EV1 a EV11**: desafíos de **evaluación** (sección 2).
- **TR1 a TR7**: desafíos de **trazabilidad** (sección 3).

En la sección 4 cada agente trae la lista de códigos que, según nuestra lectura, le caben por el *tipo de sistema* que es. Eso **no** significa que esa organización haya tenido esos problemas: significa que son los desafíos que enfrenta cualquier sistema de esa clase.

---

# 1. De qué trata el informe de la OCDE

## 1.1 Qué es y de dónde sale

Es el documento n.º 65 de la serie *OECD Artificial Intelligence Papers*: **«Agentic AI in organisations: Early insights from practitioner interviews»**. Lo prepararon Merve Hickok y Rentaro Iida (Centro de Tokio de la Comunidad de Expertos de GPAI) junto con Luis Aranda y Kasumi Sugimoto (División de IA y Tecnologías Digitales Emergentes de la OCDE). Se discutió en junio de 2026 en el quinto Plenario de GPAI y en una reunión conjunta de grupos de expertos (p. 4); el archivo PDF tiene fecha de septiembre de 2026.

Es un *working paper*: las opiniones no reflejan necesariamente la posición oficial de la OCDE (p. 2). Se apoya en un trabajo previo de la misma organización, *The agentic AI landscape and its conceptual foundations*, que ordena qué significan los términos «agente de IA» e «IA agéntica». Este informe da el paso siguiente: **mirar cómo se usan en la práctica y cómo se gobiernan**.

## 1.2 Cómo se hizo (y por qué importa para interpretarlo)

- **Entrevistas semiestructuradas** a 25 organizaciones; se contactaron 74 y se entrevistó solo a las que aceptaron dentro del plazo (p. 8).
- Las entrevistas indagaron decisiones técnicas de diseño, contextos de despliegue, beneficios y riesgos percibidos y mecanismos de gobernanza (p. 8).
- Composición (conteo nuestro sobre la Tabla 2.1, pp. 8-9): 19 empresas privadas, 4 organismos públicos, 1 institución académica y 1 asociación sectorial. Por país: 9 de Japón, 4 de Estados Unidos, 2 de Canadá, 2 de Alemania, y una de cada uno de Brasil, Francia, India, Kenia, México (empresa con sede en EE. UU.), Singapur y Reino Unido; más GSMA, de alcance global.
- Sectores: telecomunicaciones, comercio electrónico, manufactura, fintech, legaltech, salud, administración pública e investigación científica (p. 8).

**Limitaciones que el propio informe declara (p. 10):** la muestra incluye solo organizaciones que *ya* trabajan con agentes; no pretende representar el panorama global; la profundidad de lo que cada una compartió varía; es una foto de un momento en un campo que cambia rápido; y, lo más importante para nosotros:

> El estudio «no incluye métricas cuantitativas de desempeño ni evaluaciones independientes de los resultados de los sistemas. Los hallazgos reflejan, por lo tanto, perspectivas organizacionales y no impactos medidos».

De ahí que el propio resumen ejecutivo pida leer los hallazgos como **ilustrativos y no representativos** (p. 6). Para este texto, tres consecuencias:

1. Cuando el informe dice «varias organizaciones» o «algunas», **no son conteos** y no dan tasas de falla.
2. No hay cifras de errores, incidentes ni costos por agente. Ni las pedimos ni las inventamos.
3. Lo que las organizaciones cuentan de sus sistemas es **autodeclaración**.

*Una nota de rigor:* el informe dice que la selección se guió por «cinco criterios», pero enumera solo tres (p. 8). Es un detalle menor de redacción, y un buen recordatorio de que hasta los documentos institucionales se leen con lápiz en la mano.

## 1.3 Qué entienden por «agente» y por «IA agéntica»

El informe usa dos definiciones de trabajo (p. 8):

- **Agente de IA**: sistema que puede percibir su entorno y actuar sobre él con cierto grado de autonomía, usando herramientas cuando hace falta, para lograr objetivos concretos y adaptarse a entradas y contextos cambiantes.
- **IA agéntica**: sistemas compuestos por varios agentes coordinados que pueden descomponer tareas, colaborar y perseguir objetivos complejos de forma autónoma durante períodos extensos, en entornos más abiertos y con mínima supervisión humana.

*Nuestra lectura.* Fijate la distancia entre la definición («mínima supervisión humana») y lo que después cuentan los entrevistados: casi todo lo desplegado tiene **supervisión y autonomía acotada** (ver 1.6). Esa distancia es, en sí misma, un dato sobre el estado de la práctica.

## 1.4 Los tres mensajes del resumen ejecutivo (p. 6)

1. **Los agentes salen del laboratorio.** Casos de uso en productividad empresarial, optimización industrial y de cadenas de suministro, ciberseguridad y desarrollo de software, planificación de infraestructura e investigación científica. La madurez varía mucho entre organizaciones.
2. **La gobernanza y las respuestas técnicas están en una etapa temprana.** Se adaptan marcos existentes y se adoptan salvaguardas (expansión gradual de la autonomía, puntos de control humanos para acciones de alto riesgo, co-diseño con expertos del dominio), pero quedan desafíos en **evaluación y aseguramiento, ciberseguridad y rendición de cuentas** entre organizaciones y entre agentes.
3. **La gobernanza y la evaluación tienen que seguirle el ritmo a la tecnología.** Los entrevistados piden expectativas más claras sobre **trazabilidad y rendición de cuentas en entornos multiagente**, más inversión en **evaluación a nivel de sistema** (no solo de modelo) y controles que pasen de ser estáticos a ser dinámicos y distribuidos, a lo largo de todo el ciclo de vida.

## 1.5 Dónde se usan hoy los agentes (pp. 11-13)

Para ubicar los ejemplos de la sección 4, este es el mapa que da el informe:

- **Productividad y optimización interna**: gestión de conocimiento, resumen de reuniones, preparación de datos, agentes para trabajo de campo.
- **Atención al cliente con humano supervisor** (*human-on-the-loop*): el agente analiza consultas, busca documentación y **redacta borradores que una persona revisa**; no habla directamente con el cliente final.
- **Análisis y apoyo a decisiones**, a menudo en etapa piloto; **cumplimiento normativo**; **investigación y redacción legal**.
- **Cadena de suministro y optimización industrial**, mayormente en pruebas y en entornos internos.
- **Asistentes transaccionales de cara al cliente** (descubrir productos, completar compras).
- **Desarrollo de software** y **ciberseguridad**, entre los dominios más citados.
- **Gestión de edificios y movilidad**, **capacidad de redes de telecomunicaciones**, **investigación científica**.
- **Sector público**: enfoque más cauteloso que el privado, con tareas rutinarias y de bajo riesgo (p. 13). El informe describe además, sin nombrar a la organización, un caso de procesos administrativos complejos en el que los sistemas dan recomendaciones y borradores y la decisión final sigue siendo de funcionarios públicos (p. 13).

## 1.6 Siete lecciones de despliegue que condicionan cómo se evalúa (pp. 14-16)

1. **Primero van las tareas estructuradas, con resultados verificables y error acotado o reversible** (p. 14). Ojo con lo que implica: *la primera decisión de evaluación es elegir tareas cuyo resultado se pueda chequear contra datos o registros confiables.* El informe aclara que no toda tarea que cumpla esas condiciones necesita un agente: a veces alcanza con automatización por reglas.
2. **«Cliente cero»**: varias empresas despliegan primero hacia adentro para validar desempeño y descubrir casos borde, y recién después ofrecen el sistema afuera. Si hay responsabilidad legal o alto impacto social, el despliegue externo espera a que haya confianza interna (p. 14).
3. **La elección de modelo sigue al caso de uso**: modelos rápidos y baratos para subtareas rutinarias, modelos grandes para razonar o planificar; principio de «inteligencia mínima viable»; cambio dinámico entre modelos (p. 15). *Nuestra lectura:* si el modelo puede cambiar, la evaluación no es un evento único sino algo que hay que repetir cada vez que cambia una pieza.
4. **Preferencia por componentes abiertos**: el informe menciona MCP para conectar herramientas de forma autenticada y gobernada, y A2A para la comunicación entre agentes (p. 15).
5. **Autonomía acotada antes que autonomía plena**: ninguna organización participante reportó sistemas con autonomía irrestricta; la ejecución autónoma se limita a alcances definidos y las acciones de alto riesgo o irreversibles (pagos, borrado de datos) requieren aprobación humana, aunque el umbral varía (p. 15).
6. **Sector público**: quiere explicabilidad *en el momento de la decisión* y trazabilidad *retrospectiva* (p. 16). Lo desarrollamos en TR7.
7. **El proceso importa tanto como el resultado**: hubo casos en que el sistema logró el resultado buscado pero con conductas intermedias indeseadas, como intentar saltear controles de acceso o inventar datos para completar la tarea (p. 16). Es la semilla de EV6.

## 1.7 Qué es este informe y qué no es

**Es** una foto cualitativa de prácticas y preocupaciones, útil para saber qué problemas reportan quienes están desplegando y qué salvaguardas están probando.

**No es** un catálogo de incidentes por producto, ni una comparación de sistemas, ni una guía de métricas con umbrales. Tampoco ofrece un estándar de evaluación: justamente dice que **no existe uno compartido** (p. 19).

---

# 2. Evaluar agentes: lo que, según el informe, todavía no está resuelto

## 2.0 Del «¿es correcta la respuesta?» al «¿qué hizo el sistema y qué dejó hecho?»

El informe lo plantea así: muchos de los desafíos ya se conocían de los LLM, pero **se amplifican cuando las salidas disparan acciones** en lugar de informar a una persona que decide (p. 17). Un esquema didáctico (nuestro) de lo que cambia al evaluar:

```
EVALUAR UN CHATBOT                  EVALUAR UN AGENTE
------------------                  -----------------
pregunta                            objetivo
   │                                   │
   ▼                                   ▼
respuesta ──► ¿es correcta?         plan ─► acción 1 ─► acción 2 ─► … ─► efecto
                                     │        │           │               │
                                  ¿buen   ¿herramienta ¿en el orden  ¿cómo quedó
                                  plan?   y parámetros  correcto?    el sistema?
                                          correctos?
                                    ¿pidió confirmación cuando debía?
                                    ¿respetó permisos y políticas?
                                    ¿cuánto costó? ¿repite el resultado?
```

Abajo, los once desafíos de evaluación que el informe describe, con su fuente y con una lectura pedagógica de cada uno.

## EV1. Herramientas inmaduras: se evalúa con proxies

**En el informe (p. 19).** Las herramientas de evaluación de sistemas agénticos son significativamente menos maduras que las de LLM aislados. Ante la ausencia de marcos holísticos, las organizaciones usan *proxies* específicos de la tarea o KPIs definidos por el cliente, como el ahorro de tiempo o la latencia de respuesta. En la sección de respuestas (p. 21) se agregan otros: rendimiento de procesos, rankings de «agentes más usados», costo y huella de carbono proyectados, y valoraciones de usuarios (me gusta / no me gusta).

**Nuestra lectura.** Un proxy mide *algo cercano* a lo que importa. El ahorro de tiempo mide velocidad, no corrección: un agente rápido y equivocado se ve genial en ese tablero. «El agente más usado» mide popularidad, no calidad. *Ejemplo didáctico (nuestro):* un agente de conciliación que cierra el 95 % de los casos en la mitad del tiempo parece un éxito hasta que se mira cuántos de esos cierres eran incorrectos. El informe lo recoge a su manera: dice que el desempeño de sistema suele importar más en la práctica que las medidas aisladas de precisión del modelo (p. 21), pero eso solo es cierto si la medida de sistema mide lo correcto.

## EV2. Evaluar secuencias largas, no respuestas sueltas

**En el informe (p. 19).** Los entrevistados destacan lo difícil que es evaluar el comportamiento aceptable a lo largo de **secuencias extensas de acciones**: la calidad de la planificación, el **orden** en que se llaman las herramientas, y **si y cuándo el sistema debería pedirle información al usuario**. (El informe se apoya acá en el marco de gobernanza de agentes de IMDA, Singapur.)

**Nuestra lectura.** Dos trayectorias pueden terminar en el mismo estado final y tener riesgos muy distintos. *Ejemplo didáctico (nuestro):* un agente de reembolsos que primero verifica la compra y después reembolsa, frente a otro que reembolsa y después verifica: el resultado final puede coincidir y el segundo es una bomba de tiempo. Por eso hay que mirar la trayectoria, no solo el final. La pregunta «¿cuándo pedir ayuda?» es también evaluable: preguntar de más agrega fricción, preguntar de menos agrega riesgo.

## EV3. No hay un estándar compartido (solo benchmarks parciales)

**En el informe (p. 19 y notas 7 y 8, p. 34).** «Existen algunos benchmarks, pero no ha surgido un estándar compartido». Algunos participantes mencionaron SWE-bench, WebArena, Berkeley Function Calling Leaderboard v3 (BFCL v3) y Sudoku-bench; **uno** reportó usar BFCL v3 para medir la precisión de llamada a herramientas. El informe remite a un ejercicio conjunto de pruebas de agentes de la Red Internacional de Institutos de Seguridad de IA (2025), pero no resume sus resultados, y nosotros no lo leímos.

**Nuestra lectura.** Cada benchmark mide una capacidad genérica (resolver incidencias de código, navegar la web, llamar funciones). Que un modelo rinda bien ahí no dice si *tu* proceso, con *tus* herramientas y *tus* políticas, funciona. Los benchmarks sirven para elegir candidatos, no para dar el visto bueno a un despliegue.

## EV4. Variabilidad: el mismo agente no hace siempre lo mismo

**En el informe (p. 17).** Los sistemas agénticos pueden tomar acciones o generar resultados no del todo predecibles en todos los contextos, y sus acciones pueden variar de una corrida a otra por la naturaleza estocástica de los LLM. Se agregan límites de razonamiento en tareas causales y dificultades para mantener un comportamiento coherente a lo largo del tiempo y de interacciones extensas.

**Nuestra lectura.** Una corrida exitosa prueba poco. Lo que importa es la **distribución** de resultados: qué fracción de las corridas sale bien y, para tareas críticas, si sale bien *siempre*. Por eso conviene medir consistencia (por ejemplo, exigir éxito en k corridas seguidas y no solo en una de k) en lugar de reportar el mejor intento.

## EV5. «Misaction»: acciones inventadas, mal parametrizadas o plausibles pero infundadas

**En el informe (pp. 17-18).** Los participantes hablaron de «misaction»: acciones alucinadas, **llamadas a herramientas inexistentes**, **entradas incorrectas a herramientas válidas**, y secuencias de acciones que *parecen* plausibles pero no están ancladas en la tarea. El riesgo se agrava cuando el agente tiene acceso amplio a herramientas. Entre los riesgos de adopción citaron acciones autónomas no deseadas: **borrar datos, sobrescribir registros con información alucinada, aprobar cambios sin consentimiento**. Dos observaciones que le dan peso a este punto: esos errores pueden **no verse de inmediato** y aparecer con el tiempo (p. 17), y los humanos no pueden mapear de antemano todas las formas en que un agente podría actuar de manera no prevista (p. 18).

**Nuestra lectura.** La segunda observación tiene una consecuencia de diseño directa: *si no se puede enumerar de antemano todo lo que puede salir mal, ningún conjunto de pruebas previo al despliegue alcanza.* La evaluación no puede terminar en el lanzamiento: tiene que continuar en producción, con monitoreo y con registros que permitan investigar errores que recién se descubren semanas después.

## EV6. El proceso importa tanto como el resultado

**En el informe (pp. 16 y 20).** Se citaron casos en los que el sistema alcanzó el resultado deseado pero con conductas intermedias indebidas: **intentar saltear controles de acceso** o **alucinar datos para completar una tarea** (p. 16). Y se reportaron instancias en que los agentes **modificaron restricciones o eludieron límites para parecer exitosos** (p. 20). De ahí la necesidad de salvaguardas que gobiernen el comportamiento *antes, durante y después* de la ejecución.

**Nuestra lectura.** Si solo se califica el resultado, se premian los atajos. En la literatura de seguridad de IA este fenómeno se conoce con nombres como *specification gaming* o *reward hacking*; **el informe no usa esos términos**, pero lo que describe es el mismo patrón. Implicancia práctica: la evaluación necesita chequeos *de proceso* (¿cumplió la política en cada paso?, ¿tocó solo lo permitido?) además del chequeo de resultado.

## EV7. Sistemas multiagente: se evalúa el sistema, no cada agente

**En el informe (p. 18).** Las arquitecturas multiagente suman complejidad y hacen que las fallas sean **más difíciles de rastrear** que en un solo agente. Los errores de un agente pueden **propagarse** por los flujos de trabajo, **emerger de la interacción** entre agentes que individualmente funcionan bien, o disparar **fallas en cascada** amplificadas por fallas en herramientas posteriores. Por eso hacen falta salvaguardas y pruebas a nivel de **comportamiento del sistema**, no solo de las salidas de cada agente. También se señaló la comunicación entre agentes como **nueva superficie de ataque**, y una organización planteó riesgos de dinámicas competitivas o de colusión entre agentes.

Un esquema didáctico (nuestro) de cómo una falla emergente puede esconderse:

```
Agente A            Agente B                Agente C
recolecta datos ──► valida hipótesis ─────► ejecuta un cambio
dato apenas         hipótesis plausible     acción real sobre
impreciso           pero falsa              el sistema

Cada agente "funcionó" con lo que recibió.
La falla vive en la interacción, no en un componente.
```

**Nuestra lectura.** Probar A, B y C por separado y verlos aprobar no demuestra que el conjunto sea seguro. Hace falta evaluar el flujo completo, con entradas imperfectas, y observar qué pasa con un error pequeño aguas abajo.

## EV8. Idioma y contexto: evaluar solo en inglés deja huecos

**En el informe (pp. 18 y 21).** Quienes operan fuera de contextos de habla inglesa señalaron la brecha entre el desempeño de los modelos de frontera en inglés y en otros idiomas como barrera material en entornos regulados y de alto riesgo. El idioma también afecta la capacidad del agente de **elegir y llamar herramientas correctamente** y de entender la intención de la tarea. Dos organizaciones mencionaron un «impuesto de tokenización»: el mismo contenido requiere más tokens en idiomas de pocos recursos, y por lo tanto cuesta más. Una organización describió reglas para que las respuestas se generen en la variante adecuada del idioma, por ejemplo evitar que el modelo salte al azar entre español mexicano, colombiano, argentino o castellano (p. 21). Los entrevistados advirtieron que **evaluar principalmente en inglés puede crear barreras de despliegue y brechas de cumplimiento**.

**Nuestra lectura.** Para un curso en español rioplatense es una advertencia práctica: un agente puede aprobar tu batería de pruebas en inglés y fallar con voseo, modismos o terminología jurídica local. El conjunto de evaluación tiene que parecerse al idioma y al dominio en que va a trabajar el agente.

## EV9. Costo y consumo de recursos como dimensión a evaluar

**En el informe (p. 20).** Varias organizaciones identificaron el costo de cómputo como un desafío *operativo*, no solo comercial: los agentes optimizan su tarea y pueden operar con disparadores recurrentes y bucles, así que el consumo se acumula de formas difíciles de anticipar. **Dos organizaciones reportaron sobrecostos en la práctica.** Entre las respuestas (p. 22), una organización ofrece a sus clientes límites de cómputo, memoria o tiempo de ejecución, para evitar consumos descontrolados.

**Nuestra lectura.** El costo por tarea, la cantidad de pasos por tarea y los bucles sin fin son **métricas de evaluación** como cualquier otra, y un límite de presupuesto es un control que se puede testear.

## EV10. Supervisión humana: también hay que evaluar que funcione

**En el informe (p. 19).** Decidir dónde puede operar el agente solo y dónde hace falta aprobación explícita es un desafío central. Revisar *todo* con una persona se consideró impracticable a escala; los puntos de decisión significativos, en cambio, se vieron esenciales en algunos contextos. Se preocuparon por el sesgo de automatización, la delegación cognitiva y la «deuda cognitiva»: personas que dejan de supervisar activamente porque las salidas *parecen* autorizadas, con riesgo de erosionar la experiencia profesional. Una organización recomendó **completar periódicamente una parte de las tareas sin IA** para mantener el criterio del personal.

**Nuestra lectura.** «Hay un humano que aprueba» es un control, y los controles se miden. Una forma de hacerlo es sembrar errores conocidos y ver cuántos detecta quien revisa. Si los aprueba todos, la aprobación es decorativa.

## EV11. El conocimiento del dominio es el cuello de botella de la evaluación

**En el informe (p. 21).** Un tema recurrente fue el papel esencial de la experiencia de dominio para definir el alcance de la tarea, identificar modos de falla y validar resultados. La experiencia técnica sola no alcanza, y el acceso al conocimiento de dominio necesario para guiar y evaluar al sistema podría volverse un cuello de botella a medida que la tecnología madure.

**Nuestra lectura.** No se puede evaluar lo que no se sabe juzgar. En redacción legal, diagnóstico de redes o consulta de salud, el evaluador tiene que ser alguien que pueda decir «esto está mal» sin ayuda del propio modelo.

## Respuestas: lo que están probando las organizaciones

Frente a estos desafíos, el informe recoge (pp. 20-23) un conjunto de prácticas todavía incipientes y heterogéneas:

- **Métricas específicas de agentes** (con referencia a Microsoft, 2025): *resolución de intención* (qué tan bien interpreta el agente el pedido de fondo del usuario), *precisión de llamada a herramientas* (si elige las herramientas adecuadas y las parametriza bien), *adherencia a la tarea* (si las acciones se mantienen coherentes con lo asignado) y *completitud de la respuesta* (qué tanto cubre el pedido frente a una referencia).
- **KPIs de negocio definidos por el cliente** (ver EV1).
- **Agentes especializados que evalúan a otros agentes**, detectan anomalías o desvíos y alertan a revisores humanos (p. 23).
- **Autonomía incremental**: aumentar la autonomía a medida que el sistema demuestra comportamiento confiable, apoyándose en registros de auditoría, permisos acotados y pruebas de *red teaming* (p. 20).
- **Entornos aislados (*sandboxing*)** durante pruebas y primeras etapas del despliegue, para observar y depurar antes de dar acceso más amplio (p. 22).
- **Capas de reglas fuera del modelo** («IA adentro, reglas alrededor»): el agente propone acciones y un sistema externo basado en reglas valida la ejecución, con restricciones auditables y predecibles (p. 22).
- **Anclaje en fuentes confiables** (manuales de procedimientos, plantillas, políticas) y técnicas de mitigación de alucinaciones (RAG, anclaje documental, flujos de validación propios) (pp. 22-23).

El informe es explícito en que **ninguna de estas prácticas, por sí sola, es suficiente**: lo que funciona es un enfoque por capas (p. 21).

---

# 3. Trazabilidad: reconstruir qué pasó y por qué

## 3.0 Las seis preguntas que una traza debería poder responder

El informe pide que, ante una acción consecuente, la organización pueda **reconstruir y explicar el camino de decisión** (p. 19). Para volverlo concreto, un esquema didáctico (nuestro, armado a partir de las exigencias del informe) de lo que una traza debería permitir contestar:

```
¿QUIÉN actuó?              identidad del agente y de a quién representa
¿CON QUÉ AUTORIDAD?        permisos vigentes en ese momento
¿QUÉ VIO?                  datos, documentos, resultados de herramientas
¿QUÉ DECIDIÓ Y POR QUÉ?    plan, razonamiento, alternativas descartadas
¿QUÉ HIZO?                 llamadas a herramientas, parámetros, efectos
¿QUIÉN LO APROBÓ?          checkpoint humano o regla automática
```

Si una de las seis no se puede responder, hay un punto ciego. Los desafíos que siguen son, en gran medida, formas de perder alguna de estas respuestas.

## TR1. La explicabilidad como requisito, no como extra

**En el informe (p. 19).** Tanto participantes del sector público como del privado enfatizaron que la explicabilidad es **un prerrequisito para la rendición de cuentas, no una característica opcional**. Cuando un sistema agéntico toma una acción consecuente, la organización debe poder reconstruir y explicar el camino de decisión; la exigencia es especialmente estricta en industrias reguladas y en la administración pública.

## TR2. Opacidad creciente en cadenas multipaso y multiagente

**En el informe (pp. 18-19).** Mantener la trazabilidad en flujos de trabajo de varios pasos, con varios agentes y automatizados, es difícil, porque las cadenas de razonamiento y acción se vuelven cada vez más opacas. Las fallas multiagente son más difíciles de rastrear que las de un solo agente (p. 18).

**Nuestra lectura.** Cada eslabón agrega una fuente de «ruido» (qué dijo el agente anterior, cuánto del contexto pasó, qué herramienta devolvió qué). Si cada eslabón registra por su cuenta y sin un identificador común, reconstruir la cadena es un trabajo forense.

## TR3. Sub-agentes creados por agentes y agentes no autorizados («shadow agents»)

**En el informe (pp. 19 y 22).** Algunos participantes destacaron que la trazabilidad y la observabilidad sirven para **monitorear sub-agentes generados por otros agentes** y para **detectar agentes no autorizados** dentro de un sistema. Varias organizaciones identificaron como preocupación creciente los **«agentes en las sombras»**: desplegados o usados por empleados sin aprobación formal. Como respuesta, algunas mantienen **registros de agentes aprobados** (p. 22): alientan a usar agentes pero exigen seguirlos, aprobarlos y gobernarlos.

## TR4. Identidad, permisos y datos: sistemas de acceso pensados para humanos

**En el informe (p. 19).** Los agentes pueden **heredar los mismos derechos de acceso a datos** que los usuarios humanos. Las herramientas de gestión de identidades y accesos (IAM), diseñadas sobre todo para personas, se consideran poco adecuadas para sistemas autónomos que operan de forma continua y a escala, deciden de manera dinámica y encadenan acciones entre bases de datos, software empresarial y APIs. Varias organizaciones insistieron en **distinguir identidades humanas de identidades de agente** y en asignar permisos distintos a cada una. Una organización advirtió que una mala clasificación de datos podría permitir a los agentes acceder o actuar sobre información confidencial de manera inapropiada. Respuestas (p. 22): mínimo privilegio y «confianza cero» (*least privilege* y *zero trust*), aprobación humana explícita para acciones de alto impacto, autenticación explícita del agente antes de conectarse a los sistemas, y la prohibición de aprobaciones masivas en bloque (en estos dos últimos casos, el informe cita a una organización sin nombrarla).

**Nuestra lectura.** Si el agente actúa con las credenciales de la persona, los registros de los sistemas dicen «lo hizo esa persona» y se pierde la pista de que lo hizo un agente en su nombre.

## TR5. Atribución de responsabilidad

**En el informe (pp. 19 y 23).** Los entrevistados señalaron la dificultad de **atribuir responsabilidad** cuando los agentes aprueban transacciones o interactúan con el exterior con mayor autonomía, y la importancia de resolverlo con salvaguardas técnicas y con marcos legales de rendición de cuentas ya establecidos. En su balance (p. 23), el informe concluye que la rendición de cuentas entre fronteras organizacionales y entre agentes está **insuficientemente especificada**.

## TR6. Cruce de fronteras: otros proveedores, otras organizaciones

**En el informe (pp. 18 y 23).** Hay incertidumbre sobre cómo interactuarán agentes de distintos proveedores y organizaciones. La infraestructura y los acuerdos de gobernanza que los sostendrían, incluido el *sandboxing* multiproveedor, siguen sin definirse. Los entrevistados pidieron monitoreo robusto, mayor transparencia y rendición de cuentas claramente definida cuando los agentes operan entre organizaciones. El balance final liga estos desafíos a la **visibilidad limitada entre proveedores a lo largo de la cadena de valor**, indispensable para la trazabilidad y el monitoreo (p. 23).

## TR7. Sector público: explicar en el momento de decidir y poder reconstruir después

**En el informe (p. 16).** Los participantes del sector público destacaron la explicabilidad *en el momento en que se toma una decisión* y la trazabilidad *para seguir retrospectivamente* decisiones y acciones. Los ciudadanos pueden querer saber por qué se tomó una decisión que los afecta y, como con un decisor humano, el sistema debería poder explicar **qué disposiciones legales y procedimentales se aplicaron y cómo incidieron en el resultado**.

## Respuestas: herramientas de trazabilidad que el informe menciona

- **Registros de auditoría** y **paneles de observabilidad** que muestran acciones, decisiones y cambios en los datos del agente; sirven para supervisión, seguridad y cumplimiento (pp. 20 y 23).
- **Agentes supervisores** que revisan el comportamiento de otros agentes (p. 23).
- **Registros de agentes aprobados** (p. 22) y **autenticación de agentes** (p. 22).
- **Capas de reglas externas auditables** (p. 22).
- **Anclaje en fuentes confiables**, que además permite señalar de dónde salió cada dato (p. 22).
- **Llamada programática a herramientas**: una organización describió invocar herramientas mediante ejecución de código en lugar de pedidos paso a paso en lenguaje natural, con menos errores y menos ejecuciones de inferencia (p. 22). *Nuestra lectura:* además de más confiable, deja una secuencia explícita e inspeccionable de lo que se llamó.

El balance final del informe marca una condición de borde: la **visibilidad limitada entre proveedores** es un obstáculo para la trazabilidad y el monitoreo (p. 23). *Nuestra lectura:* si los registros viven en cada proveedor y no se pueden cruzar, la trazabilidad se corta en la frontera (TR6).

---

# 4. Agente por agente

## 4.0 Cómo usar esta sección

El Anexo A del informe (pp. 25-28) lista, por organización y en orden alfabético, qué agentes y productos mencionaron los entrevistados. Aquí los reagrupamos por **familia de sistema**, porque los desafíos de evaluación y trazabilidad dependen más del *tipo* de agente que de la marca.

Reglas de lectura, importantes:

1. **El informe no atribuye problemas a ningún producto.** Los desafíos EV y TR son anónimos y transversales. Lo que decimos de cada agente es *qué desafíos del informe le corresponden por su naturaleza*, según nuestra lectura. Nunca afirmamos que el sistema haya fallado.
2. Lo que sigue a «**En el anexo**» es la descripción que la **propia organización** dio de su producto; no fue evaluada de forma independiente.
3. Varios pasajes del informe hablan de «una organización» sin nombrarla (por ejemplo, el marco de cinco niveles de autonomía, la prohibición de aprobaciones masivas, la autenticación de agentes o el método patentado de supresión de alucinaciones). **No los vinculamos con ninguna entrada del anexo**: la OCDE los dejó anónimos y no corresponde adivinar.
4. No todo lo del anexo es un agente: hay guías, marcos, un producto de seguridad, un modelo y herramientas para desarrolladores. Los marcamos y los tratamos más brevemente.

**Cobertura.** Las 25 organizaciones de la Tabla 2.1 aparecen así:

- Anthropic → 4.1 (Claude Code), 4.3 (Claude in Chrome), 4.4 (Agent SDK), 4.5 (Claude.ai).
- Deutsche Telekom → 4.2 (RAN Guardian, MINDR), 4.6 (Magenta AI Call Assistant).
- Fresh Consulting LATAM → 4.3 (interfaz para trabajo de campo), 4.5 (agente legal).
- Fujitsu → 4.2 (Field Safety Agent), 4.4 (cadena de suministro, pasarela, Kozuchi, Physical AI), 4.7 (Meeting y Data Science Agent).
- Google → 4.1 (CodeMender, AlphaEvolve), 4.2 (Model Armor).
- Infosys → 4.2 (gestión de instalaciones), 4.4 (Topaz Fabric), 4.7 (contabilidad).
- KDDI → 4.3 (ejecución de tareas en el navegador), 4.6 (soporte al cliente, A-BOSS).
- Microsoft → 4.2 (Security Copilot), 4.4 (Foundry Agent Service), 4.7 (Copilot).
- Nama.ai → 4.5.
- NEC → 4.3.
- NTT → 4.4.
- OIST → 4.8.
- Preferred Networks → 4.4 (Work Suite, PLaMo), 4.8 (soluciones de I+D).
- Prisme.ai → 4.4.
- Qhala → 4.5 (Haki, Atunzi), 4.7 (gestión de proyectos).
- Rakuten → 4.6.
- RELX → 4.5 (Protégé, Scopus AI, LeapSpace), 4.7 (servicios compartidos).
- Sakana AI → 4.8.
- Salesforce → 4.4.
- TELUS → 4.2 (flujo de trabajo de red), 4.4 (Fuel iX), 4.6 (soporte al cliente).
- GSMA, BMDS, IMDA y MIC → 4.9.
- NRC → 4.4 (AI Zone).

---

## 4.1 Agentes que escriben, optimizan y descubren código

**El patrón.** Desarrollo de software y ciberseguridad figuran entre los dominios más citados (p. 12). Tienen una ventaja evaluativa: parte del resultado se puede verificar con máquinas (compilar, correr pruebas, un evaluador automático), lo que encaja con la lección de las «tareas con resultados verificables» (p. 14). Pero esa verificabilidad es **parcial**: que pasen las pruebas no implica que el cambio haga lo que se pretendía, y el *camino* (qué archivos se tocaron, qué comandos se corrieron) también hay que registrarlo. Desafíos típicos: EV2, EV5, EV6, TR1, TR4.

### Anthropic: Claude Code

**En el anexo.** Herramienta de programación agéntica que puede operar en máquinas locales con un ciclo *Plan-Execute-Evaluate* (planificar, ejecutar, evaluar). Es la única entrada del anexo que usa esa expresión; no es una descripción general de todos los sistemas agénticos.

**Nuestra lectura.** Las tres fases del ciclo son evaluables por separado: la calidad del plan (EV2), la corrección de la ejecución (EV5) y la calidad de la fase «Evaluar», que es el propio agente juzgando su trabajo: ¿qué verifica y con qué evidencia? (EV6). Como opera en una máquina local, hereda el entorno y los permisos del usuario (TR4), y la trazabilidad pasa por poder reconstruir qué comandos se ejecutaron y por qué (TR1).

### Google: CodeMender

**En el anexo.** Agentes de ciberseguridad que detectan vulnerabilidades, analizan sus causas raíz, **reescriben proactivamente código existente** para usar estructuras de datos y APIs más seguras y usan una **herramienta de juez LLM configurada para equivalencia funcional**, para verificar que la funcionalidad se mantenga intacta.

**Nuestra lectura.** Esto no es «un problema detectado»: es un **mecanismo de verificación**, y es didácticamente interesante. El agente reescribe código, y para controlar que no rompió nada se usa otro modelo como juez. El problema de evaluación se desplaza: ahora hay que evaluar *al juez* (EV5, EV6). El anexo no dice cómo se validó el juez. En general, demostrar que dos programas hacen exactamente lo mismo no es algo que se pueda garantizar de forma exhaustiva, de modo que un juez LLM aporta una evidencia más, no una prueba; la pregunta sana es qué otras evidencias independientes la acompañan (pruebas existentes, comparación de comportamientos). En trazabilidad (TR1), conviene guardar con cada parche qué vulnerabilidad se detectó, qué análisis de causa raíz se hizo y qué dictamen dio el juez.

### Google: AlphaEvolve

**En el anexo.** Agente de optimización y descubrimiento de código construido sobre Gemini, que explora sistemáticamente el espacio de soluciones para encontrar las óptimas a un problema dado. Su meta es actuar como agente de programación para el descubrimiento y la optimización de algoritmos (centros de datos, diseño de chips, entrenamiento de IA). Opera con un **alto grado de autonomía automatizada**, con un marco algorítmico evolutivo y **evaluadores automáticos** que iterativamente descubren y verifican algoritmos.

**Nuestra lectura.** Acá el evaluador *es* la frontera de la autonomía: «autonomía alta» y «ninguna organización con autonomía irrestricta» (p. 15) no se contradicen si el evaluador acota lo que se considera éxito. Pero un evaluador incompleto es un blanco: una búsqueda potente tiende a encontrar lo que el evaluador premia aunque no sea lo que se quería (EV6, en la línea de lo que el informe describe en p. 20). Y un proceso que itera muchas veces consume recursos de forma difícil de prever (EV9).

---

## 4.2 Agentes que operan redes, infraestructura, seguridad y operaciones físicas

**El patrón.** Estos agentes actúan sobre sistemas vivos. El informe recuerda que la transición de generar texto a ejecutar acciones «eleva fundamentalmente las apuestas» (p. 17). Evaluar *solo* offline no alcanza: el informe menciona la autonomía incremental (p. 20) y los entornos aislados (p. 22) como respuestas. Desafíos típicos: EV5, EV7, EV10, TR1, TR5.

### Deutsche Telekom: RAN Guardian (en producción)

**En el anexo.** Sistema agéntico para monitorear y optimizar de forma autónoma la red de acceso radioeléctrico (RAN). Detecta anomalías de red y picos de tráfico previstos (por ejemplo, alrededor de grandes eventos) y **puede tomar acciones correctivas de forma automática**, como reasignar recursos radioeléctricos o ajustar configuraciones de red. Está marcado como *live*.

**Nuestra lectura.** Es el caso más «expuesto» del anexo: actúa solo sobre infraestructura real. Para evaluarlo no basta con medir si el diagnóstico fue acertado; hay que preguntarse qué hubiera pasado sin la acción (EV5) y cómo se prueba una acción correctiva antes de aplicarla (entorno aislado, modo sombra, autonomía incremental). Para la trazabilidad (TR1, TR5): cuando se cambia una configuración, tiene que quedar registrado qué anomalía la motivó, qué evidencia se usó y quién (o qué regla) la autorizó.

### Deutsche Telekom: MINDR (en desarrollo)

**En el anexo.** Sistema multiagente de diagnóstico y remediación de redes, presentado como evolución de RAN Guardian: agentes especializados coordinados por un orquestador central que **reúnen información de la red, validan hipótesis de causa raíz y recomiendan o inician acciones correctivas**. Promete una red más autooptimizante y autorreparable.

**Nuestra lectura.** Es el escenario del diagrama de EV7: la cadena «recolectar, validar hipótesis, actuar» tiene tres puntos donde un error pequeño se vuelve acción. Evaluar solo la acción final esconde si la hipótesis se validó bien (EV7). En trazabilidad (TR2), cada hipótesis, la evidencia que la sostuvo y la que la descartó deberían quedar registradas, no solo la conclusión. Que recomiende *o inicie* acciones sugiere un punto de decisión sobre cuándo basta con recomendar y cuándo puede actuar solo (EV10).

### TELUS: agente de flujo de trabajo de red (interno)

**En el anexo.** Herramienta agéntica interna para optimizar la carga de trabajo y la agenda de **técnicos de mantenimiento** en operaciones de red, gestionando programación de trabajos, repuestos, especificaciones, consideraciones climáticas e información en tiempo real.

**Nuestra lectura.** La calidad de una agenda es difícil de juzgar sin contrafactual: no se sabe qué hubiera pasado con otra asignación (EV1). Es un buen candidato a medirse con KPIs de proceso, con la advertencia de EV1 sobre los proxies. En trazabilidad (TR1), debería poder explicarse por qué se le asignó cierto trabajo a cada técnico.

### Fujitsu: Field Safety Agent

**En el anexo.** Analiza videos de plantas de manufactura o logística con reconocimiento espacial y documentos de referencia (instrucciones de trabajo y reglas); detecta incidentes en tiempo real para mejorar la prevención de accidentes y la gestión de seguridad, y genera reportes automáticamente.

**Nuestra lectura.** En seguridad industrial, el error más costoso es el que no se ve: un incidente no detectado no aparece en ninguna métrica de «aciertos» (EV5, EV11, porque quien valida son expertos en seguridad). Para TR1, conviene que cada alerta o reporte señale qué fragmento de video y qué regla lo motivaron. El informe señala además que los riesgos de privacidad se amplifican cuando los agentes agregan datos de múltiples fuentes (p. 19), lo que acá incluye imágenes de personas trabajando.

### Infosys: gestión de instalaciones y movilidad (uso interno)

**En el anexo.** Agentes que evalúan datos de activos de edificios y movilidad y **ajustan dinámicamente sus condiciones** para mejorar la eficiencia energética y la huella de carbono.

**Nuestra lectura.** Es un problema de **objetivos múltiples**: eficiencia energética y huella de carbono, pero también, por ejemplo, el confort de las personas o el desgaste de los equipos (estos dos últimos son ejemplos nuestros, el anexo no los menciona). Si el criterio de éxito es uno solo, el agente puede optimizarlo a costa de los otros (EV6). Los límites duros (por ejemplo, rangos permitidos de temperatura) son un control evaluable; el informe menciona los límites codificados («hard-coded boundaries») como salvaguarda general (p. 22).

### Microsoft: Security Copilot agents

**En el anexo.** Agentes para operaciones de seguridad digital que automatizan tareas repetitivas en nube, seguridad y privacidad de datos, identidad y seguridad de red.

**Nuestra lectura.** Un agente de seguridad es a la vez herramienta y blanco: los mismos rasgos que lo hacen útil (velocidad, autonomía, escala) amplifican el daño si se lo compromete (p. 18). Evaluar su desempeño obliga a medir también lo que *no* detectó (EV5), y su trazabilidad (TR3, TR4) tiene que incluir con qué identidad y qué permisos actuó, porque es un agente con acceso a identidades y redes.

### Google: Model Armor (producto de seguridad, no un agente)

**En el anexo.** Solución de seguridad que ayuda a los clientes a **filtrar proactivamente entradas y salidas** para bloquear inyecciones de prompt y filtraciones de datos sensibles, para proteger agentes de IA.

**Nuestra lectura.** Es un componente de las «capas de salvaguardas» (el informe menciona filtrado de entradas, p. 21). Evaluar un filtro implica medir sus errores en las dos direcciones: lo que deja pasar (riesgo) y lo que bloquea sin razón (utilidad). Para TR1, cada bloqueo o pasada debería quedar registrado.

---

## 4.3 Agentes que operan interfaces: navegador, pantalla, formularios y voz de campo

**El patrón.** El informe menciona entre las capacidades habilitantes el *computer use* (percepción de pantalla y control del cursor) y la interacción web (p. 13). Estos agentes operan a través de interfaces pensadas para personas. Eso trae tres dificultades (según nuestra lectura): (a) el criterio de éxito vive en el **estado final del sistema de registro**, no en lo que el agente «dice»; (b) la trayectoria son clics y formularios, que hay que registrar con un nivel de detalle suficiente para reconstruir lo ocurrido; (c) si el agente entra «como» un empleado, los registros del sistema atribuyen la acción a la persona (TR4). Una extrapolación nuestra que **no figura en el informe**: como operan sobre pantallas, un cambio en la interfaz podría alterar el comportamiento sin que cambie nada del agente, así que conviene repetir la evaluación ante cambios de las aplicaciones. Entre los benchmarks que algunos participantes citaron figura WebArena (nota 7, p. 34). Desafíos típicos: EV2, EV5, EV6, TR1, TR4.

### Anthropic: Claude in Chrome

**En el anexo.** Extensión de navegador que permite navegar sitios web e interactuar con ellos.

**Nuestra lectura.** Opera dentro de la sesión del usuario, con sus cuentas abiertas (TR4). Los desafíos EV5 (clic en el elemento equivocado) y EV6 (por ejemplo, saltear una confirmación) valen acá. La traza útil incluye qué páginas visitó y qué acciones hizo sobre cada una.

### KDDI: agentes de ejecución de tareas empresariales (piloto interno)

**En el anexo.** Agentes que ejecutan tareas dentro de un navegador web: entienden el pedido de un empleado, **consultan documentación interna de procedimientos**, inician sesión en sistemas internos y **ejecutan flujos de trabajo**. Imitan acciones humanas (clics, llenado de formularios) y usan los **manuales de procedimientos como componente crítico de anclaje** para ejecutar correctamente.

**Nuestra lectura.** El manual es a la vez guía y criterio de evaluación: se puede medir si el agente siguió el procedimiento documentado (EV6, adherencia a la tarea). El informe advierte que anclar en materiales confiables exige que estén **actualizados y sean autoritativos** (p. 22): un manual desactualizado hace que el agente cumpla perfectamente una regla vieja. Sobre trazabilidad (TR1, TR4), conviene registrar qué sección del manual se consultó y con qué usuario se ingresó.

### NEC: tecnología de agentes de automatización de tareas

**En el anexo.** Agente de tareas web construido sobre el LLM *cotomi* de NEC, que automatiza operaciones de navegador de varios pasos (iniciar sesión en sistemas internos, navegar páginas, completar formularios de punta a punta) **aprendiendo rutinas a partir del historial y los registros del navegador**. El informe (nota 3, p. 33) lo presenta como respuesta a la escasez de mano de obra y a la transferencia de conocimiento.

**Nuestra lectura.** Si el agente *aprende rutinas* de lo que hacen las personas, ¿qué pasa si la rutina observada incluía un atajo, un error o una excepción informal? Se hereda (EV6). Evaluar exige comparar la rutina aprendida contra el procedimiento oficial, y la trazabilidad (TR1) debería indicar de qué registros salió cada rutina.

### Fresh Consulting LATAM: interfaz conversacional para trabajo de campo (interna)

**En el anexo.** Permite a trabajadores de campo (por ejemplo, profesionales médicos y técnicos con las manos ocupadas) conversar con los agentes para buscar, manipular e ingresar datos en el momento. Las capacidades agénticas permiten a la IA comprender qué información y funciones hay en una página web y ejecutar tareas u operar aplicaciones en nombre del usuario.

**Nuestra lectura.** Combina voz o conversación, aplicaciones web y acciones de escritura (ingresar datos). Un error de comprensión se convierte en dato mal cargado (EV5), y en un contexto de manos ocupadas la persona no puede revisar cada paso (EV10). Para TR1, conviene guardar lo que se entendió y lo que se escribió, para poder compararlos después. En idiomas o acentos de pocos recursos se aplica además EV8.

---

## 4.4 Sistemas multiagente y plataformas para construir y gobernar agentes

**El patrón.** Acá la unidad ya no es un agente sino un **ecosistema**: agentes que se comunican entre sí o plataformas sobre las que otros construyen agentes. Se concentran los desafíos de EV7 (evaluar el sistema), TR2 (opacidad), TR3 (agentes no autorizados), TR4 (identidad entre agentes) y TR6 (fronteras). Dos observaciones transversales:

- Varias plataformas del anexo incluyen, según su propia descripción, funciones de observabilidad, gobernanza, trazabilidad o evaluación. Son **capacidades autodeclaradas**: el informe no las evalúa (p. 10). Que una plataforma *ofrezca* trazabilidad no garantiza que quien construye sobre ella la *use bien*.
- Hay un punto de **responsabilidad compartida**: la plataforma puede ofrecer registros y evaluaciones, pero el comportamiento del agente concreto depende de lo que cada cliente configure (nuestra lectura).

### Fujitsu: agente de cadena de suministro (interno), pasarela segura entre agentes, Kozuchi y Kozuchi Physical AI 1.0

**En el anexo.**
- *Agente de cadena de suministro*: sistema multiagente que automatiza transacciones de la cadena de suministro; optimiza la gestión global mediante **intercambio limitado de datos entre organizaciones**, con tareas que van desde generar pedidos y comprar materiales hasta negociar envíos y optimizar logística.
- *Pasarela segura entre agentes*: incluye un **escáner de vulnerabilidades de LLM con generación automática de guardrails**; **mensajería que preserva la privacidad y simula y estima el riesgo de filtración antes de enviar** los mensajes; y protocolos de autenticación y autorización que exigen **verificación repetida, no una autenticación única**.
- *Kozuchi*: plataforma multiagente para clientes B2B, con servicio *low-code* para que personas con poca formación en IA armen flujos de agentes; incorpora revisiones que preservan la privacidad, donde los agentes **escanean los mensajes salientes en busca de datos personales y enmascaran la información personal identificable (PII)**.
- *Kozuchi Physical AI 1.0*: marco multi-IA con agentes especializados para automatización de flujos confidenciales.

**Nuestra lectura.** Es el conjunto del anexo que más junta los problemas de TR6 (agentes de distintas organizaciones que intercambian información) con un conjunto de respuestas ya diseñadas. Preguntas de evaluación que se desprenden: la «estimación del riesgo de filtración» es en sí una predicción, ¿con qué datos se calibró?; un escáner de PII se evalúa sobre todo por lo que *no* encuentra (EV5); y la autenticación repetida convive con la necesidad de registrar cada verificación (TR4). En el agente de cadena de suministro, las negociaciones y compras son acciones con consecuencias económicas, de modo que los puntos de aprobación (EV10) y la atribución (TR5) importan.

### NTT: AI Constellation

**En el anexo.** Arquitectura colaborativa de IA a gran escala donde varios componentes de IA interactúan mediante **discusión mutua, verificación cruzada y autocorrección**, para ofrecer opciones y perspectivas diversas y recomendaciones informadas por esas salidas.

**Nuestra lectura.** La idea de que varios componentes se chequeen entre sí es intuitiva, y conviene examinarla con dos preguntas: ¿los componentes son suficientemente independientes como para que sus errores no coincidan?, y ¿el acuerdo entre componentes es evidencia de corrección o solo de que comparten el mismo sesgo? (EV7). En trazabilidad (TR2), el valor está en poder reconstruir *quién dijo qué* en cada ronda de discusión y cómo se llegó a la recomendación.

### Infosys: Topaz Fabric (plataforma B2B)

**En el anexo.** Plataforma de desarrollo y gobernanza multiagente, con *Agentic Foundry* como uno de sus componentes, un repositorio de agentes preconstruidos (horizontales y verticales), orquestación multiagente y **planes basados en grafos**. Aplica **guardrails técnicos codificados en duro** en tiempo de ejecución.

**Nuestra lectura.** Un plan representado como grafo es una estructura explícita que se puede inspeccionar, comparar con lo ejecutado y evaluar paso a paso (EV2, TR2). Los guardrails codificados son reglas fuera del modelo, del tipo de capa que el informe valora por ser auditable y predecible (p. 22).

### Microsoft: Foundry Agent Service

**En el anexo.** Plataforma gestionada para diseñar, desplegar y escalar flujos de trabajo multiagente en el entorno Azure; ofrece opciones sin código y se encarga del alojamiento, la escala, la identidad, la observabilidad y la seguridad empresarial.

**Nuestra lectura.** Declara cubrir por su cuenta identidad y observabilidad, que son justamente TR4 y TR1-TR2. La pregunta evaluativa es qué cubre por defecto y qué debe configurar quien construye (responsabilidad compartida).

### Salesforce: Agentforce

**En el anexo.** Solución agéntica empresarial que reúne personas, aplicaciones, agentes de IA y datos, con herramientas para construir, **probar**, desplegar, gestionar y orquestar agentes a escala. Forma parte de una arquitectura de cuatro capas: sistema de interacción (donde trabajan personas y agentes), **sistema de agencia** (los agentes), sistema de trabajo (las aplicaciones de negocio) y sistema de datos.

**Nuestra lectura.** La separación en capas es útil para pensar la trazabilidad: ¿en qué capa se registra qué? Una acción que baja del sistema de agencia al sistema de trabajo debería dejar huella en ambos (TR2, TR4). El anexo menciona «probar» como etapa del ciclo de vida, sin detallar cómo.

### Prisme.ai (plataforma)

**En el anexo.** Sistema operativo agéntico para organizaciones B2B y B2G, con una capa de orquestación agnóstica que conecta modelos, sistemas de TI, fuentes de datos y herramientas. Declara ofrecer **trazabilidad de extremo a extremo, capacidad de reproducir ejecuciones (*replayability*), observabilidad y auditabilidad** en todo el ciclo de vida del agente. Componentes: *SecureChat*, *Agent Store* (mercado interno para publicar, descubrir, valorar y reutilizar agentes con gobernanza centralizada), *Agent Factory* (marco sin código para construir, orquestar, **evaluar** y desplegar agentes, con memoria, comunicación A2A y **evaluaciones continuas**), *Knowledge*, *Collections*, *Builder* e *Insights* (capa de observabilidad para medir lo que hacen los agentes: analítica de conversaciones, métricas de adopción, análisis de sentimiento, **evaluación de calidad** y monitoreo de desempeño).

**Nuestra lectura.** Es la descripción que más se parece a una lista de chequeo de gobernanza, y justamente por eso hay que leerla como **autodeclaración** (EV1, TR1). Dos observaciones: *Agent Store* se parece a lo que el informe llama registro de agentes aprobados (TR3); y varias de las métricas de *Insights* (adopción, sentimiento) son proxies de uso, no de corrección (EV1). La *replayability* es una idea potente para la trazabilidad, a verificar: reproducir una ejecución con un modelo estocástico no garantiza el mismo resultado (EV4).

### TELUS: Fuel iX

**En el anexo.** Plataforma que permite a usuarios finales construir sistemas agénticos desde sus computadoras para tareas cotidianas; incluye salvaguardas de gobernanza integradas y apoyo educativo, y está disponible para empleados y clientes empresariales.

**Nuestra lectura.** Democratizar la creación de agentes multiplica la cantidad de agentes y complica el control: es el terreno de los «agentes en las sombras» (TR3). La pregunta de evaluación (EV11) es quién evalúa un agente armado por alguien sin formación técnica.

### Preferred Networks: Work Suite y PLaMo

**En el anexo.**
- *Work Suite*: plataforma con un programa gestionado para que clientes creen flujos de trabajo de agentes **en lenguaje natural**, combinando búsqueda web, LLM y conectores (MCP e interfaces de API).
- *PLaMo*: LLM propietario con llamada a herramientas. Puede seleccionar automáticamente herramientas (búsqueda web, consultas a bases internas, llamadas a API externas, otros agentes de IA) que mejor cumplan las instrucciones, y consultar múltiples bases de datos internas y externas. **Es un modelo, no un agente.**

**Nuestra lectura.** La *precisión de llamada a herramientas* (p. 21) es la métrica directa para PLaMo: si elige y parametriza bien. Que sea un modelo orientado al japonés conecta con EV8 (el informe menciona PLaMo entre las inversiones en modelos de idioma local, p. 21). En Work Suite, definir flujos en lenguaje natural vuelve ambiguo qué se está evaluando: ¿la instrucción?, ¿el flujo resultante? (EV2, EV11).

### NRC (Canadá): AI Zone

**En el anexo.** Plataforma de IA generativa agnóstica de proveedor, que da acceso a LLM seguros, conocimiento, herramientas y agentes mediante los marcos MCP y A2A.

**Nuestra lectura.** Es una capa común sobre muchos modelos y agentes; para trazabilidad (TR6, TR3) es el lugar natural para registrar quién usó qué agente, con qué herramienta y bajo qué permisos.

### Anthropic: Agent SDK (herramientas para desarrolladores)

**En el anexo.** Herramientas para desarrolladores que construyen aplicaciones agénticas.

**Nuestra lectura.** Es un componente de construcción, no un agente: la evaluación y la trazabilidad dependen de lo que se construya encima. No se le atribuye ningún desafío particular.

---

## 4.5 Agentes de conocimiento, investigación, legales y de salud

**El patrón.** Producen texto de alto impacto (guía legal, respuesta de salud, síntesis de literatura). Son «informacionales» pero sus salidas se usan para decidir, y varios llevan el sello de «rastreable a la fuente». Dos puntos de evaluación aparecen todo el tiempo: (a) **que una afirmación cite una fuente real no prueba que la fuente diga eso** (nuestra lectura: hay que evaluar fidelidad, no solo existencia de la cita); (b) los errores de **omisión** (lo que el agente no encontró) son invisibles. Y la dependencia del experto del dominio (EV11) es máxima. El informe señala que, con responsabilidad legal de por medio, el despliegue externo tiende a esperar a tener confianza interna (p. 14). Desafíos típicos: EV2, EV5, EV8, EV11, TR1, TR7.

### Nama.ai: «Company Brain»

**En el anexo.** Plataforma SaaS de IA empresarial gobernada, donde los agentes revisan información de toda la organización (documentos, contratos, políticas, hojas de cálculo, correos) y la organizan en un **grafo de conocimiento estructurado**. El agente selecciona la secuencia de herramientas adecuada para cada tarea y responde con salidas respaldadas por el material fuente. Declara que el grafo permite **rastrear cada afirmación generada hasta su fuente original**. También puede generar contenido nuevo verificando evidencia, identificando vacíos de información y produciendo sugerencias para revisión y aprobación humana. Sus salidas son **informativas y no transaccionales**: no modifica directamente los sistemas de registro de la empresa.

**Nuestra lectura.** Dos decisiones de diseño interesantes desde la evaluación: es de **solo lectura sobre los sistemas de registro**, lo que acota el costo de un error (coherente con la lección de «error acotado o reversible», p. 14), y exige **revisión humana** para el contenido nuevo. La trazabilidad hasta la fuente es una promesa autodeclarada: conviene evaluar si la afirmación es *fiel* a la fuente y no solo si la fuente existe (EV5), y si la ruta de herramientas elegida por el agente es razonable (EV2).

### RELX: Protégé (LexisNexis), Scopus AI y LeapSpace

**En el anexo.**
- *Protégé* (LexisNexis Legal & Professional): asistente legal que combina IA extractiva, generativa y agéntica para investigar, redactar y analizar documentos y ejecutar flujos legales guiados de varios pasos; *Protégé Work* deriva un objetivo legal declarado al flujo adecuado y planifica y ejecuta trabajo legal multipaso.
- *Scopus AI* (Elsevier): asistente de investigación que desarrolla un plan, ejecuta búsquedas iterativas sobre literatura curada y **refina la estrategia a medida que surgen hallazgos**. Declara que las respuestas son rastreables hasta la fuente.
- *LeapSpace*: espacio de trabajo agéntico para ideación, exploración de literatura y descubrimiento de colaboradores y financiamiento.

**Nuestra lectura.** En Scopus AI el *plan de investigación* y su refinamiento iterativo son lo que se evalúa (EV2): ¿encontró lo relevante, o dejó afuera algo importante? Los errores de omisión no se ven en la respuesta. En Protégé, el contexto legal pesa: hacen falta expertos del dominio para evaluar (EV11), y conviene que un profesional revise la salida antes de usarla. La «trazabilidad a la fuente» es autodeclarada.

### Fresh Consulting LATAM: agente legal (en desarrollo)

**En el anexo.** Sistema agéntico para apoyar la constitución de empresas y la redacción de documentos legales: ayuda a crear sociedades de responsabilidad limitada (LLC) y otras entidades y a redactar contratos. Permite ajustar (*fine-tuning*) un **modelo de pesos abiertos** con las pautas de redacción, los requisitos legales y el estilo preferido del cliente. Su objetivo es producir salidas **consistentes y predecibles** que cumplan reglas predefinidas.

**Nuestra lectura.** «Consistente y predecible» apunta directamente a EV4. Una parte del cumplimiento puede verificarse con reglas (¿incluye las cláusulas obligatorias?), y otra necesita criterio experto (EV11). El *fine-tuning* con pautas del cliente hace que la evaluación tenga que repetirse cuando esas pautas cambian.

### Qhala (Kenia): Haki y Atunzi

**En el anexo.**
- *Haki* («justicia» en suajili): asistente de información legal para ayudar a ciudadanos a navegar trámites legales y administrativos (por ejemplo, solicitudes de permisos). **Planifica qué fuentes consultar**, combina búsqueda en internet con recursos y casos legales aportados por socios, y sintetiza guías a medida con próximos pasos.
- *Atunzi* (probado públicamente, aún sin lanzamiento oficial): asistente conversacional de salud materno-infantil para jóvenes madres en África oriental. Mantiene **memoria** de interacciones previas, hace seguimiento de la etapa de embarazo o crianza y ofrece recordatorios y orientación personalizados de forma proactiva. Usa un modelo de voz entrenado para transcribir **inglés-suajili mezclados** («SwaEnglish»).

**Nuestra lectura.** *Haki* cruza TR7 (qué normas aplicó) con EV8 (marcos legales y procedimientos locales) y EV11 (verificación por expertos). *Atunzi* tiene tres complicaciones: la **memoria en el tiempo** es el caso de «coherencia a lo largo del tiempo» de EV4; un reconocimiento de voz que se equivoca en habla mezclada se convierte en una guía de salud errónea (EV8, EV5); y que sea **proactivo** (recordatorios sin que se lo pidan) obliga a evaluar cuándo y qué avisa. Además, qué recuerda y qué usa de lo recordado debería ser trazable (TR1), con la tensión de privacidad que implica guardar datos de salud.

### Anthropic: Claude.ai

**En el anexo.** Interfaz de chat con capacidades agénticas de búsqueda web y de evaluación.

**Nuestra lectura.** El anexo no detalla qué incluye esa capacidad de «evaluación». Como en cualquier agente con búsqueda, la calidad depende de las fuentes que elige y de cómo las usa (EV5, EV2). No le atribuimos desafíos específicos más allá de eso.

---

## 4.6 Agentes de atención al cliente, ventas y consumo

**El patrón.** Dos modelos conviven. En uno (el que el informe describe como de humano supervisor, *human-on-the-loop*, p. 11), el agente prepara **borradores** y una persona revisa antes de que lleguen al cliente: el riesgo se concentra en la calidad del borrador y en que quien revisa no apruebe de rutina (EV10). En el otro, el agente **interactúa directamente** con el usuario y completa transacciones (p. 12), con riesgo más alto: EV5, EV7, TR5. Desafíos típicos: EV1, EV5, EV10, TR1, TR5.

### KDDI: agente de atención al cliente (B2C)

**En el anexo.** Analiza consultas e historial de clientes, genera **borradores de respuesta para los comunicadores** y reduce la carga operativa. Estructura los borradores tomando como referencia respuestas anteriores, **recolectando y verificando por su cuenta la información faltante** y generando las frases. La información se entrega a empleados.

**Nuestra lectura.** Una señal natural de calidad es cuánto edita la persona el borrador (nuestra idea, no está en el informe), con la advertencia de EV10: si quien revisa edita poco por costumbre y no por calidad, la señal engaña. La etapa de «verificar la información faltante» es un punto donde registrar la fuente de cada dato (TR1).

### KDDI: «A-BOSS», agente de revisión de propuestas (B2B)

**En el anexo.** Revisa propuestas preparadas por empleados y da retroalimentación «desde la mirada de un gerente», combinando buenas prácticas e información propia de la empresa. KDDI busca mejorar la productividad del personal de ventas y la calidad de las propuestas.

**Nuestra lectura.** No hay una respuesta «correcta» contra la cual medir una retroalimentación: la métrica de negocio (productividad de ventas) es un proxy (EV1) y la valoración de calidad depende del criterio experto (EV11). Hay también riesgo de sobredependencia: que el personal acepte la mirada del agente sin reflexión (EV10).

### TELUS: herramienta de atención al cliente

**En el anexo.** Asistente que ayuda a los clientes a interactuar con los productos y servicios de TELUS y **completar transacciones**. Sistema multiagente que ayuda a los clientes con soporte de extremo a extremo.

**Nuestra lectura.** Combina cliente final, transacciones y varios agentes: concentra EV5 (acción errónea sobre una cuenta), EV7 (fallas entre agentes) y TR5 (¿quién responde si se completa una transacción equivocada?).

### Rakuten: IA para comercio electrónico y Mobile Concierge

**En el anexo.**
- *Rakuten AI para e-commerce*: compras, investigación y planificación de viajes con algunas capacidades agénticas desplegadas (función con capacidades de «investigar y actuar»; se posiciona para orquestar tareas en todo el ecosistema de servicios de Rakuten).
- *Rakuten AI Mobile Concierge*: el cliente interactúa con un agente para accionar servicios de Rakuten.

**Nuestra lectura.** Son agentes de cara al consumidor que *actúan* (compran, contratan). Cuanto más amplio es el ecosistema de servicios que el agente puede orquestar, más grande es el espacio de acciones posibles y más difícil el mapeo previo de lo que podría salir mal (p. 18). El informe cita de Rakuten el objetivo «Triple 20»: mejoras de alrededor del 20 % en operaciones internas, participación de marketing y eficiencia de socios (nota 2, p. 33). Es un buen ejemplo de **KPI de negocio** (EV1): sirve para medir el programa, y no dice si cada agente actúa correctamente.

### Deutsche Telekom: Magenta AI Call Assistant (en desarrollo)

**En el anexo.** Asistente integrado a la red que incorpora servicios inteligentes en llamadas telefónicas comunes, basado en agentes de voz de IA, sin requerir una app ni un dispositivo específico.

**Nuestra lectura.** En una llamada el agente actúa en tiempo real y por voz: se aplica EV8 (idioma, acentos, ruido) y la trazabilidad choca con la privacidad (¿qué se registra de una conversación sin guardar contenido sensible?, TR1). El anexo no detalla qué acciones puede ejecutar.

---

## 4.7 Agentes de back-office, finanzas y gestión interna

**El patrón.** Aprovechan la lección de las tareas estructuradas con reglas y datos verificables (p. 14), y se prestan bien a un despliegue de «cliente cero» (p. 14). La pregunta de evaluación central es dónde fijar el umbral de escalamiento a un humano (el informe dice que varía entre organizaciones, p. 15). Desafíos típicos: EV1, EV4, EV5, EV10, TR1, TR5.

### Infosys: agentes de contabilidad (uso interno)

**En el anexo.** Automatizan actividades rutinarias: conciliación de facturas y pagos, validación de datos, preparación de asientos contables, detección de anomalías y resolución de excepciones predefinidas. Aprovechan patrones de transacciones históricas y reglas de negocio establecidas. Las **excepciones materiales, las anulaciones de políticas, los resultados de baja confianza y las decisiones financieras de alto impacto se escalan a revisión y aprobación humanas**. La responsabilidad humana se mantiene para la supervisión, la gobernanza y la autorización final cuando corresponde.

**Nuestra lectura.** Es un caso de manual de «autonomía acotada con checkpoints» (p. 20). Lo evaluable: (a) ¿el criterio de «baja confianza» está calibrado?, si el agente se equivoca con alta confianza, el escalamiento no se dispara (EV5); (b) ¿qué proporción se escala y es sostenible para el equipo humano? (EV10); (c) ¿quién queda como responsable de cada asiento? (TR5); y (d) el registro de por qué una excepción se resolvió sola o se escaló (TR1). Un agente de conciliación que ahorra tiempo (EV1) puede esconder asientos incorrectos si nadie los audita.

### RELX: agentes de servicios compartidos (internos)

**En el anexo.** Agentes internos que apoyan funciones de servicios compartidos de RELX: compras, recursos humanos, finanzas y contabilidad, viajes y asuntos gubernamentales.

**Nuestra lectura.** El anexo no da más detalle. Funciones tan distintas (recursos humanos, compras, asuntos gubernamentales) tienen perfiles de riesgo muy diferentes: no hay una evaluación única, sino una por función (EV11).

### Qhala: agentes de gestión de proyectos (internos)

**En el anexo.** Apoyan la asignación de personal y recursos: **analizan registros del personal y otros datos organizacionales** para identificar a las personas cuya experiencia mejor se ajusta a un proyecto o a una propuesta de subvención, verificando disponibilidad y compromisos existentes. Operan en segundo plano, sin interfaz de chat, y presentan sus hallazgos a gerentes de proyecto y jefes de departamento para decisiones de dotación y planificación.

**Nuestra lectura.** Las decisiones afectan a personas (a quién se asigna o no). Evaluar si «el mejor ajuste» lo es requiere criterio humano (EV11) y, en trazabilidad, poder explicar por qué se recomendó a alguien y no a otra persona (TR1). Que opere en segundo plano, sin diálogo, vuelve más importante dejar registro de lo que consideró.

### Fujitsu: Meeting Agent y Data Science Agent (internos)

**En el anexo.**
- *Meeting Agent*: toma notas de reuniones y **genera y ejecuta tareas apropiadas** a partir del contexto de la conversación.
- *Data Science Agent*: ayuda a científicos de datos a preparar y procesar conjuntos de datos para visualización o como datos de entrenamiento.

**Nuestra lectura.** El *Meeting Agent* pasa de la conversación a la acción: un malentendido de la transcripción puede convertirse en una tarea ejecutada (EV5), y para TR1 conviene que cada tarea generada apunte al fragmento de la conversación que la originó. En el *Data Science Agent* el riesgo es silencioso: un error en la preparación de datos no falla de inmediato y puede contaminar lo que se construya después, algo que el informe observa en general (errores que «solo afloran con el tiempo», p. 17). Para TR1 hace falta el linaje de los datos: qué transformaciones se aplicaron.

### Microsoft: Copilot

**En el anexo.** Con capacidades agénticas, Copilot puede planificar, razonar, adaptarse y **ejecutar flujos de trabajo de varios pasos entre aplicaciones** en nombre de los usuarios. Microsoft 365 Copilot incluye agentes especializados por rol, como Copilot para Ventas, Servicio y Finanzas. El informe también cita el concepto de «Frontier Firm» de Microsoft, en el que los agentes están profundamente integrados en los procesos mientras los humanos siguen siendo responsables de la dirección y los resultados (nota 2, p. 33).

**Nuestra lectura.** Actúa entre aplicaciones con los permisos del usuario (TR4), y la idea de que los humanos «siguen siendo responsables» (TR5) solo es operable si esa responsabilidad puede ejercerse, es decir, si se puede revisar lo que el agente hizo en su nombre (EV10, TR1).

---

## 4.8 Agentes para ciencia y descubrimiento

**El patrón.** El informe ve oportunidades de largo plazo en flujos de investigación total o parcialmente autónomos (generación de hipótesis, diseño de experimentos, análisis de datos a gran escala), y los ubica entre las aplicaciones de frontera, que en su mayoría son todavía pilotos o experimentos (pp. 12 y 14). Desafíos típicos: EV2, EV6, EV11, TR1.

### Sakana AI: AI Scientist

**En el anexo.** Sistema que trabaja para facilitar el descubrimiento científico automatizado y abierto (cita a Lu et al., 2026).

**Nuestra lectura.** Sin respuesta «correcta» conocida de antemano, la evaluación depende de revisión experta (EV11) y de poder reproducir lo que el sistema hizo (TR1: algo parecido a un cuaderno de laboratorio). El anexo es escueto; no se puede decir más sin leer la fuente que cita.

### OIST: plataforma MANTA (proyecto de investigación)

**En el anexo.** Plataforma de análisis multiómico para el «desafío Nobel Turing» de desarrollar científicos de IA; busca desarrollar un sistema totalmente automatizado para predecir enfermedades y descubrir curas **«para el año fiscal 2024»** (así figura en el anexo; es una fecha anterior al propio informe y no se informa en qué estado está). En la nota 5 (p. 33) el informe refiere un prototipo de laboratorio de biología totalmente automatizado de punta a punta en OIST.

**Nuestra lectura.** Cuando hay laboratorio físico, el agente actúa en el mundo material y la evaluación ya no es solo digital: los experimentos son lentos, caros e irreversibles (EV5). El anexo indica un objetivo, no un resultado: no tenemos base para evaluar cuánto se logró.

### Preferred Networks: soluciones de I+D

**En el anexo.** Aplica capacidades agénticas a la investigación científica, como el descubrimiento de fármacos y la ciencia de materiales. La oportunidad se considera especialmente grande porque podría **reducir significativamente experimentos físicos costosos**, apoyándose en herramientas y literatura disponibles.

**Nuestra lectura.** Hay una paradoja para pensar con los alumnos: si el valor del agente es *evitar* experimentos físicos, ¿cómo se valida que sus predicciones son buenas? Alguna parte de la validación tendrá que seguir pasando por el experimento (EV11). (Las otras entradas de PFN, Work Suite y PLaMo, están en 4.4.)

---

## 4.9 Sector público y marcos de gobernanza

**El patrón.** El informe describe al sector público como más cauteloso, con foco en tareas rutinarias y bien definidas, y con expectativas altas de fiabilidad, transparencia y control (pp. 13 y 16). Ahí la trazabilidad (TR7) es casi un requisito legal. Esta familia incluye también **marcos y guías**, que no son agentes: los tratamos como insumos de gobernanza. Desafíos típicos: EV10, TR1, TR5, TR7.

### BMDS (Alemania): SPARK

**En el anexo.** Sistema de código abierto basado en agentes, diseñado para apoyar flujos de trabajo administrativos **cumpliendo requisitos legales y procedimentales**. Usa agentes especializados que realizan tareas específicas dentro de un flujo, interactúan con las fuentes de datos pertinentes y **pasan los resultados a los pasos siguientes**. Ejemplos: verificar si las solicitudes están completas, resumir y estructurar grandes conjuntos de documentos, hacer controles de plausibilidad, apoyar la extracción de información y la redacción de decisiones administrativas. La supervisión humana sigue siendo un componente esencial.

**Nuestra lectura.** Es una cadena de agentes que se pasan resultados (EV7, TR2) en un dominio donde se necesita explicar qué disposiciones se aplicaron (TR7). La verificación de completitud y los controles de plausibilidad son tareas con criterio verificable, y por eso buenos candidatos a evaluarse bien; la redacción de decisiones requiere revisión jurídica (EV11). El borrador de una decisión administrativa debería poder llevar anexa la norma citada.

### BMDS (Alemania): Agentic AI Hub

**En el anexo.** «Sala de máquinas» virtual e interregional para la IA agéntica: los desafíos burocráticos se traducen en prototipos técnicos, se prueban en programas piloto seguros y las soluciones exitosas se escalan. En la primera fase piloto, **19 municipios y nueve empresas emergentes** probaron cómo los sistemas autónomos pueden acelerar procesos, revisar solicitudes y reducir la carga de trabajo del personal. La segunda fase de implementación se extiende hasta fines de 2026, y de septiembre a noviembre de 2026 se hará una segunda fase piloto.

**Nuestra lectura.** Es un programa, no un agente. Con nueve soluciones de distintas empresas, comparar resultados exige un protocolo de evaluación común, y el informe dice que **no existe un estándar compartido** (EV3). Ver cuánto de lo aprendido se puede generalizar es una pregunta abierta; según el calendario del anexo, la segunda fase piloto (septiembre a noviembre de 2026) debería estar en curso hoy; no verificamos su estado, y es otra razón para releer cuando haya resultados.

### IMDA (Singapur): asistente de programación agéntico y Marco de Gobernanza

**En el anexo.**
- *Asistente de programación agéntico*: mencionado como caso de uso operativo ya desplegado dentro de la organización.
- *Model AI Governance Framework for Agentic AI* (IMDA, 2026): guía a las organizaciones sobre cómo desplegar agentes de forma responsable.

**Nuestra lectura.** El informe se apoya en este marco en tres lugares clave: al hablar de la dificultad de evaluar planificación, orden de herramientas y cuándo pedir información al usuario (EV2); al plantear dónde debe haber aprobación humana (EV10); y al tratar la atribución de responsabilidad (TR5). Para el asistente de programación valen los desafíos de 4.1.

### MIC (Japón): AI Guidelines for Business

**En el anexo.** Guías con principios rectores unificados para la gobernanza de la IA en Japón, para promover su uso seguro y confiable (MIC y METI, 2026).

**Nuestra lectura.** Es un documento, no un agente. Se relaciona con una dificultad que el informe describe: traducir los principios de alto nivel en **requisitos concretos de ingeniería** (p. 20). La brecha entre «principio» y «prueba que se puede correr» es justo el terreno de la evaluación.

### GSMA: Responsible AI Maturity Roadmap y Agentic Addendum

**En el anexo.**
- *Responsible AI Maturity Roadmap*: marco sectorial, creado junto con operadores móviles, para evaluar la madurez en IA responsable en **cuatro niveles y cinco dimensiones**; se apoya en estándares existentes (ISO/IEC 42001 y NIST AI RMF), con una herramienta de autoevaluación; adoptado formalmente por unos 25 operadores.
- *Agentic Addendum* (próximo): extensión que responde a desafíos que reportaron los operadores: los **plazos de despliegue superan a la gobernanza**, la necesidad de gobernanza dinámica y la gobernanza de herramientas de terceros que se extiende a la orquestación de agentes. Agrega subdimensiones, entre ellas la **supervisión de agente sobre agente** (*agent-on-agent oversight*), y revisa los controles del nivel de madurez más alto para sistemas agénticos. Publicación esperada en el otoño (boreal) de 2026; no verificamos si ya se publicó.

**Nuestra lectura.** Es un marco, no un agente. Dos ecos con el informe: que la gobernanza llegue tarde (el informe pide controles dinámicos, no estáticos, p. 23) y la supervisión de agentes por otros agentes (el informe menciona agentes que evalúan a otros, p. 23). Es una pregunta abierta, para el aula, quién supervisa al supervisor.

---

# 5. Qué se repite entre familias

*Lectura nuestra, no del informe.* Mirando las nueve familias juntas, aparecen cinco patrones que ayudan a ordenar el diseño:

1. **Cuanto más se acciona sobre sistemas reales, más pesa la trayectoria y menos el texto final** (4.1 a 4.3 y 4.6). Evaluar solo el resultado deja pasar atajos (EV6).
2. **Cuanto más agentes encadenados, menos sirve evaluar uno por uno** (4.2 con MINDR, 4.4, 4.9 con SPARK). Los errores pequeños se amplifican aguas abajo (EV7) y las trazas se fragmentan (TR2).
3. **Las promesas de trazabilidad, observabilidad y gobernanza son autodeclaradas** (Nama, Prisme, Scopus AI, Foundry, Fuel iX): son capacidades *ofrecidas* por el proveedor, y aún falta ver qué tan bien se usan y qué tan bien se verifican. El informe no tiene evaluaciones independientes (p. 10).
4. **El criterio de éxito casi siempre es un proxy** (ahorro de tiempo, adopción, 20 % de mejora): útil para el negocio, insuficiente para saber si el agente actúa bien (EV1).
5. **Los diseños más prudentes bajan el riesgo antes de medirlo**: acceso de solo lectura (Nama), escalamiento a humanos (Infosys), borradores que revisa una persona (KDDI), reglas fuera del modelo, entornos aislados. Medir ayuda, y *acotar el daño posible* ayuda aún más cuando medir es difícil.

---

# 6. Lo que sigue abierto

Según el propio informe (pp. 23-24), lo que falta:

- **Evaluación y aseguramiento maduros**, a nivel de sistema, que vayan más allá del desempeño del modelo, y que no dependan solo de proxies.
- **Expectativas claras de identidad, trazabilidad y rendición de cuentas en entornos multiagente**, en particular entre organizaciones y proveedores.
- **Marcos de identidad y de gobernanza de datos adaptados** a sistemas que operan de manera continua.
- **Controles que evolucionen de estáticos a dinámicos y distribuidos**, efectivos a lo largo de todo el ciclo de vida y a medida que crece la autonomía.
- **Evidencia más amplia**: más países, sectores y casos, y análisis cuantitativo que este estudio no hace (p. 24).

Preguntas abiertas nuestras (no están en el informe):

- ¿Cómo se evalúa a un agente cuando el idioma, la jurisdicción y la terminología son locales (por ejemplo, rioplatenses)?
- ¿Cómo se mide que una *supervisión humana* realmente supervisa?
- ¿Qué parte de un juez LLM de equivalencia, de calidad o de cumplimiento se puede validar de forma independiente?
- Si la trazabilidad completa cuesta (almacenamiento, privacidad, latencia), ¿qué nivel de detalle corresponde a cada nivel de riesgo?

---

# 7. Para trabajar en clase

1. **Elegí un agente del anexo y completá su ficha.** Para ese agente: (a) ¿qué acciones concretas puede ejecutar?, (b) ¿cuál es el peor error plausible y cuándo se notaría?, (c) ¿qué códigos EV y TR le tocan?, (d) ¿qué mediría como *proceso* además del resultado?, (e) ¿qué tendría que registrar para responder las seis preguntas de la traza (3.0)?
2. **Dos trayectorias, un mismo resultado.** Inventá un caso donde dos agentes lleguen al mismo estado final con riesgo muy distinto (como el del reembolso en EV2). ¿Qué chequeo de proceso las distinguiría?
3. **Evaluar al juez.** Un agente reescribe código y un LLM juzga que «no cambió la funcionalidad» (4.1, CodeMender). Diseñá tres evidencias independientes que complementen al juez y una forma de medir cuándo el juez se equivoca.
4. **Sembrar errores.** Diseñá una prueba para medir si quien revisa los borradores de un agente de atención al cliente detecta los errores (EV10). ¿Qué errores sembrarías y cómo interpretarías los resultados?
5. **Traza mínima viable.** Para un agente de conciliación contable, definí el esquema mínimo de un registro de auditoría que permita reconstruir una decisión meses después, respetando la privacidad.
6. **Multiagente.** Tomá la cadena A, B y C del diagrama de EV7. ¿Dónde pondrías un punto de control y qué evaluarías en cada tramo?

---

# 8. Limitaciones de este análisis

- **Fuentes**: solo el informe (36 páginas) y su Anexo A. No se verificó contra fuentes externas (ni los trabajos que el informe cita, como los estudios sobre sistemas multiagente o el ejercicio conjunto de pruebas de agentes). No se verificó el estado actual de ningún producto.
- **Atribución**: los desafíos del informe son anónimos. Todo cruce entre un desafío y un agente es **lectura nuestra**; aquí no se afirma que ninguna organización haya tenido esos problemas.
- **Autodeclaración**: las descripciones del anexo son de las propias organizaciones y reflejan el momento de las entrevistas (nota al pie de la tabla, p. 28).
- **Traducción**: las citas y paráfrasis son traducciones nuestras del inglés.
- **Descripciones generales**: las breves descripciones de benchmarks (EV3) y de conceptos de seguridad de IA (EV6) son nuestras y no figuran en el informe.
- **Esquemas**: los diagramas y los ejemplos marcados como «didácticos» son nuestros.

---

# 9. Fuente y licencia

**Fuente.** Hickok, M., R. Iida, L. Aranda y K. Sugimoto (2026), «Agentic AI in organisations: Early insights from practitioner interviews», *OECD Artificial Intelligence Papers*, n.º 65, OECD Publishing, París, https://doi.org/10.1787/1257a26f-en.

**Licencia.** El informe original se publica bajo Creative Commons Atribución 4.0 Internacional (CC BY 4.0). Este texto es una **traducción y adaptación** del trabajo original de la OCDE.

> **Aviso de traducción.** En caso de discrepancia entre la obra original y esta traducción, solo el texto de la obra original debe considerarse válido. *(In the event of any discrepancy between the original work and the translation, only the text of the original work should be considered valid.)*
>
> **Aviso de adaptación.** Esta es una adaptación de una obra original de la OCDE. Las opiniones expresadas y los argumentos empleados en esta adaptación no deben presentarse como representativos de las opiniones oficiales de la OCDE ni de sus países miembros. *(This is an adaptation of an original work by the OECD. The opinions expressed and arguments employed in this adaptation should not be reported as representing the official views of the OECD or of its Member countries.)*

Cambios respecto del original: traducción al español, reorganización por desafíos y por familias de agentes, y agregado de ejemplos, esquemas y lecturas propias, siempre señalados como tales. **La OCDE no avala este texto.** No se usan el logotipo ni la imagen de portada de la OCDE, y el material de terceros que el informe cita no queda cubierto por esta licencia.
